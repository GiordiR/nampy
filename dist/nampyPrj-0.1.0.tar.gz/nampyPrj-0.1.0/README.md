# nampyPrj
Numerical Analysis Methods Python Project

### Installation
```
pip install nampyPrj
```
