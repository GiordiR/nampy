from nampyPrj.integral.integral import *
from nampyPrj.integral.integral_vec import *
