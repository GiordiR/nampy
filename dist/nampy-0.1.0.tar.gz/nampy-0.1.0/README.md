# nampy
Numerical Analysis Methods Python

### Installation
```
pip install nampy
```
